from __future__ import division
import pandas as pd
import numpy as np

def sp(file):#split train and test set
    n=len(file)
    train=int(n*0.53)#The number is the scale of the train set 
    test=int(n*0.47)#The number is the scale of the test set
    train_number=file.iloc[0:train,]
    test_number=file.iloc[test:,]
    return train_number,test_number

def get_number_distance(train,test):#get the distance
    distance = (((train.sub(test,axis=1))**2).sum(axis=1))**0.5
    distance.sort_values(axis=0,ascending=True,inplace=True)  
    return distance

def getAllDistance(trainfile,testfile):
    a=0; b=[]
    for row in testfile.itertuples(index=False, name='Pandas'):        
        distance=get_number_distance(trainfile,row)
        #print('distance is:',type(distance))
        test=[a]*np.shape(distance.values)[0]                  
        list1={ 'train' : np.array(distance.index),'distance':distance.values,'test':test}
        dfEachTestRowDistance=pd.DataFrame(list1)
        b.append(dfEachTestRowDistance) 
        a=a+1    
    alldistance=pd.concat(b,axis=0)    
    return alldistance

def nTrain(dataFrame):#z-score normalization 
    result = dataFrame.copy()
    colList = list(dataFrame.columns)    
    for col in range(len(colList)):
        colMean = dataFrame[colList[col]].mean()
        colStd = dataFrame[colList[col]].std()
        result[colList[col]] = (dataFrame[colList[col]] - colMean)/colStd    
    return result

def nTest(testData, trainData):#z-score normalization 
    result = testData.copy()
    colList = list(testData.columns)
    for col in range(len(colList)):
        colMean = trainData[colList[col]].mean()
        colStd = trainData[colList[col]].std()
        result[colList[col]] = (testData[colList[col]] - colMean)/colStd
    return result

def main(df_file):
    trainfile,testfile=sp(df_file)
    trainfile.rename(columns={'Class/ASD':'Class'}, inplace = True)
    #print(trainfile)
    
    
    kList=[1,5,11,21,41,61,81,101] #the k value we want to test
    trainLable = trainfile[['Class']].copy()
    testLable = testfile[['Class/ASD']].copy()
    trainfile.drop('Class' , axis=1, inplace=True)
    testfile.drop('Class/ASD' , axis=1, inplace=True)
    ntrainfile = nTrain(trainfile)  #get normalized data
    ntestfile = nTest(testfile,trainfile)
    #print(ntrainfile,'\n',ntestfile,'\n')
    alldistance=getAllDistance(ntrainfile , ntestfile)
    #print(alldistance)
    
    for kValue in range(len(kList)) :
        a=0
        predictedLabel = []
        for row in ntestfile.itertuples(index=False, name='Pandas'):
            b=alldistance[alldistance['test']==a]
            #print(b)
            c=b.loc[:(kList[kValue]-1) ,'train']
            #print(trainLable)
            #print(c)
            d=trainLable.iloc[c]['Class']
            d=d.value_counts()
            #print(d)
            predictedLabel.append(d.idxmax())
            a+=1 
               
        tmpList={'Class/ASD' : predictedLabel}
        predictedTestLabel = pd.DataFrame(tmpList)
        differenceLabel = testLable.sub(predictedTestLabel , axis=1)    
        accurateClassCount = len(differenceLabel[differenceLabel['Class/ASD'] ==0 ])    
        accuracyPercent =(100-accurateClassCount/testLable['Class/ASD'].count()*100)
        print('k=',kList[kValue],':',accuracyPercent, '%' ) 
    
df_adult= pd.read_csv('D:/my python/1/adult.csv')
df_adol= pd.read_csv('D:/my python/1/adol1.csv')
df_child= pd.read_csv('D:/my python/1/child.csv')

print('adult:')
main(df_adult)
print('adol:')
main(df_adol)
print('child:')
main(df_child)