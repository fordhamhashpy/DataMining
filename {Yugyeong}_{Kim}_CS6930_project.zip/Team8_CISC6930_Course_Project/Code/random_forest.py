
# Data Mining Project (Random Forest Algorithm)

import pandas as pd
import seaborn as seaBorn
#import graphviz
from os import system
from sklearn import tree
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix 
from sklearn.metrics import classification_report
from sklearn.metrics import accuracy_score  

                                # Dataset import
data = pd.read_csv("Autism-Adult-Data.CSV", na_values = "?")
#data = pd.read_csv("Autism-Child-Data.csv", na_values = "?")
#data = pd.read_csv("Autism-Adolescent-Data.csv", na_values = "?")

                                # Print dataset imported
print('Imported Training DataSet:\n', data.head())

                                # Data preprocessing
totalMissingData = data.isnull().sum().sort_values(ascending = False)
percentMissingData = (data.isnull().sum() / data.isnull().count() * 100).sort_values(ascending = False)
missingData = pd.concat([totalMissingData, percentMissingData], axis = 1, keys = ['Total', 'Percent'])

print('Total Missing Data:\n', missingData.head())
data = data.fillna(data.mean())
data.rename(columns = {'Class/ASD': 'decision_class'}, inplace = True)
data.jundice = data.jundice.apply(lambda x: 0 if x == 'no' else 1)
data.decision_class = data.decision_class.apply(lambda x: 0 if x == 'NO' else 1)
data.austim = data.austim.apply(lambda x: 0 if x == 'no' else 1)
lblEncode = LabelEncoder()
data.gender = lblEncode.fit_transform(data.gender) 

data.drop(['result'], axis = 1, inplace = True)
X=data[['A1_Score', 'A2_Score', 'A3_Score', 'A4_Score', 'A5_Score', 'A6_Score', 'A7_Score', 'A8_Score', 
       'A9_Score', 'A10_Score', 'age', 'austim', 'gender', 'jundice']]
Y=data[['decision_class']]

print('\nTest Data Matrix:')
print(X, Y.shape)

                                # Splitting data into training dataset and test dataset
X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size = 0.2)
feature_names = X.columns
print('\nFeature Names:\n', feature_names)

                                # Random Forest algorithm implementation
from sklearn.ensemble import RandomForestClassifier

classifier = RandomForestClassifier(n_estimators=100, random_state=45)
classifier.fit(X_train, y_train.values.ravel())
y_pred= classifier.predict(X_test)
                                # Data visualisation
print('y Prediction: ', y_pred)
print("\n Accuracy is %3f" %(accuracy_score(y_test,y_pred) * 100))
print(classification_report(y_test, y_pred)) 

autismStatus = [1, 0]
confusionMatrix = confusion_matrix(y_test, y_pred, labels = autismStatus)
seaBorn.heatmap(confusionMatrix, annot = True, xticklabels = autismStatus, yticklabels = autismStatus);
featureTrgt = ['1','0']
tree.export_graphviz(classifier.estimators_[0], out_file='randomforest.dot', feature_names = feature_names, class_names = featureTrgt, filled = True, rounded = True, special_characters = True)
system("dot -Tpng randomforest.dot -o Data.png")

