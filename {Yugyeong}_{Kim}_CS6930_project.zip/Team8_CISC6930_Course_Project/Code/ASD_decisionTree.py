# -*- coding: utf-8 -*-
# CISC 6930 - Data Mining
#
# Course Project
# 1: Intro This project requires you to explore classification algorithms on real-world datasets, 
# and write a report explaining your experimental results. The language of implementation is up to 
# you — the requirements are: 1) your program be able to accept the data files (posted with the project 
# assignment in BB) as the input to your program, and 2) your program be able to classify instances and 
# analyze risk factors. You are free to construct whatever user interface for your program, but you must 
# fully document your interface. 
# 
# 2: Your algorithm should be based on algorithms and techniques learned in our course. Usually a straight 
# forward implementation of one method will not lead to satisfactory performance. Your algorithm can be a 
# combination of methods and should incorporate one or more data mining techniques when the situation arises. 
# These techniques may include (and certainly not limited to): 
#      - Handling imbalanced dataset 
#      - Proper imputation methods for missing values
#      - Different treatment of various type of features: continuous, discrete, categorical, etc.
# 
# 3: You’ll be examining the behavior of your classification algorithm(s) on Autism Spectrum Disorder (ASD) 
# screening for adults, adolescents and children. The three datasets are obtained from the UCI machine 
# learning lab. Each dataset is presented with a description file and a data file.
#      
# Each data file contains 20 features to be utilized for predicting the ASD cases and determining the 
# influential autistic traits. In particular, there are ten behavioral features based on answers to 10 
# questions, plus ten individuals characteristics that have proved to be effective in detecting the ASD 
# cases from controls in behaviour science. The 10 questions are designed differently for the adults, 
# adolescents and children groups. Therefore, you need to be careful if you plan to combine these datasets 
# for further analysis. Questionnaires for each group are also posted in BB for your reference. 
# 
# 4: The Goal of the project is to accurately predict the ASD cases and analyze what are the most important 
# factors in ASD prediction.
#
# Prof. Yijun Zhao
# 12/02/2019
# Alexey Sanko

import pandas as panda
from os import system
import graphviz
import seaborn as seaBorn
import matplotlib.pyplot as pyPlot
import seaborn as seaBorn
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix 
from sklearn.metrics import classification_report
from sklearn.metrics import accuracy_score  
from sklearn.tree import DecisionTreeClassifier
from sklearn import tree

### Main Program ###
# Change pvar accordingly to the datasets' name used to output a file with its proper name
pvar = 'adultData'
data = panda.read_csv('Autism-Adult-Data.csv', na_values = ['?'])
# data = panda.read_csv('Autism-Child-Data.csv', na_values = ['?'])
# data = panda.read_csv('Autism-Adolescent-Data.csv', na_values = ['?'])
data = data.dropna()

# Print dataset imported
print('Imported Training DataSet:\n', data.head())

totalMissingData = data.isnull().sum().sort_values(ascending = False)
percentMissingData = (data.isnull().sum() / data.isnull().count() * 100).sort_values(ascending = False)
missingData = panda.concat([totalMissingData, percentMissingData], axis = 1, keys = ['Total', 'Percent'])


print('Total Missing Data:\n', missingData.head())

data.rename(columns = {'Class/ASD': 'decision_class'}, inplace = True)
data.jundice = data.jundice.apply(lambda x: 0 if x == 'no' else 1)
data.decision_class = data.decision_class.apply(lambda x: 0 if x == 'NO' else 1)
data.autism = data.autism.apply(lambda x: 0 if x == 'no' else 1)
lblEncode = LabelEncoder()
data.gender = lblEncode.fit_transform(data.gender) 
data.drop(['result'], axis = 1, inplace = True)
X = data[['A1_Score', 'A2_Score', 'A3_Score', 'A4_Score', 'A5_Score', 'A6_Score', 'A7_Score', 'A8_Score', 
       'A9_Score', 'A10_Score', 'age', 'autism', 'gender', 'jundice']]
Y = data[['decision_class']]

print('\nTest Data Matrix:')
print(X, Y.shape)

X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size = 0.2, random_state = 101)
feature_names = X.columns

print('\nFeature Names:\n', feature_names)

entropy = DecisionTreeClassifier(criterion = "entropy", random_state = 42, max_depth = 3, min_samples_leaf = 5)
entropy.fit(X_train, y_train)
yPrediction = entropy.predict(X_test)

print('yPrediction: ', yPrediction)
print("\nAccuracy is %3f" %(accuracy_score(y_test,yPrediction) * 100))
print(classification_report(y_test, yPrediction)) 

autismStatus = [1, 0]
confusionMatrix = confusion_matrix(y_test, yPrediction, labels = autismStatus)
seaBorn.heatmap(confusionMatrix, annot = True, xticklabels = autismStatus, yticklabels = autismStatus);
featureTrgt = ['1','0']
tree.export_graphviz(entropy, out_file = 'tree.dot', feature_names = feature_names, class_names = featureTrgt, 
       filled = True, rounded = True, special_characters = True)
system("dot -Tpng tree.dot -o %s.png" %pvar)

plot, ax = pyPlot.subplots(figsize = (9, 6))
confusionMtrx = confusion_matrix(y_test, yPrediction, labels = autismStatus)
gr = seaBorn.heatmap(confusionMtrx, annot = True, ax = ax, xticklabels = autismStatus, linewidths = 0.5, yticklabels = autismStatus)
plot.savefig('%s.pdf' %pvar)
