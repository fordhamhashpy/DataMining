#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Dec  2 17:15:33 2019

@author: yugyeongkim
"""

from sklearn import datasets
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Perceptron
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import numpy as np
import pandas as pd



data_adult = pd.read_csv("Autism-Adult-Data.CSV")
data_adol = pd.read_csv("Autism-Adolescent-Data.CSV")
data_child = pd.read_csv("Autism-Child-Data.CSV")

#delete rows that contain ? from ethnicity colums.
#df_adult = data_adult[data_adult.ethnicity != "?"]
df_adult = data_adult.replace("?",2)
#df_adult["ethnicity"].mean()
df_adol = data_adol.replace("?",2)
df_child = data_child.replace("?",2)

#encoding categorical values for adults
no_gender = {"gender": {"f":0,"m":1}}
no_jund = {"jundice":{"yes":0,"no":1}}
no_class = {"Class/ASD" : {"YES":0,"NO":1}}
no_asd = {"austim": {"yes":0,"no":1}}

df_adult= df_adult.drop(["used_app_before","age_desc","relation","contry_of_res","ethnicity"], axis=1)
df_adult.replace(no_jund,inplace=True)
df_adult.replace(no_class,inplace=True)
df_adult.replace(no_gender,inplace=True)
df_adult.replace(no_asd,inplace=True)

#encoding values for adol
df_adol= df_adol.drop(["used_app_before","age_desc","relation","contry_of_res","ethnicity"], axis=1)
df_adol.replace(no_jund,inplace=True)
df_adol.replace(no_class,inplace=True)
df_adol.replace(no_gender,inplace=True)
df_adol.replace(no_asd,inplace=True)
#encoding for child

df_child= df_child.drop(["used_app_before","age_desc","relation","contry_of_res","ethnicity"], axis=1)
df_child.replace(no_jund,inplace=True)
df_child.replace(no_class,inplace=True)
df_child.replace(no_gender,inplace=True)
df_child.replace(no_asd,inplace=True)


#spliting data into training and test sets.

X_adult = df_adult.drop('Class/ASD',axis=1)
y_adult = df_adult['Class/ASD']
X_adult_train,X_adult_test,y_adult_train,y_adult_test = train_test_split(X_adult,y_adult,test_size = 0.20)

X_adol = df_adol.drop('Class/ASD',axis=1)
y_adol = df_adol['Class/ASD']
X_adol_train,X_adol_test,y_adol_train,y_adol_test = train_test_split(X_adol,y_adol,test_size = 0.20)

X_child = df_adol.drop('Class/ASD',axis=1)
y_child = df_adol['Class/ASD']
X_child_train,X_child_test,y_child_train,y_child_test = train_test_split(X_child,y_child,test_size = 0.20)

sc = StandardScaler()
sc.fit(X_adult_train)
sc.fit(X_adol_train)
sc.fit(X_child_train)

# Apply the scaler to the X training data
X_adult_train_std = sc.transform(X_adult_train)
X_adol_train_std = sc.transform(X_adol_train)
X_child_train_std = sc.transform(X_child_train)
# Apply the SAME scaler to the X test data
X_adult_test_std = sc.transform(X_adult_test)
X_adol_test_std = sc.transform(X_adol_test)
X_child_test_std = sc.transform(X_child_test)

# Create a perceptron object with the parameters: 40 iterations (epochs) over the data, and a learning rate of 0.1
ppn = Perceptron(max_iter=70, eta0=0.15, random_state=0)

# Train the perceptron
ppn.fit(X_adult_train_std, y_adult_train)
ppn.fit(X_adol_train_std, y_adol_train)
ppn.fit(X_child_train_std, y_child_train)
# Apply the trained perceptron on the X data to make predicts for the y test data
y_adult_pred = ppn.predict(X_adult_test_std)
y_adol_pred = ppn.predict(X_adol_test_std)
y_child_pred = ppn.predict(X_child_test_std)

# View the predicted y test data
print(y_adult_pred)
print(y_adol_pred)
print(y_child_pred)

# View the true y test data
print(y_adult_test)
print(y_adol_test)
print(y_child_test)

# View the accuracy of the model, which is: 1 - (observations predicted wrong / total observations)
print("Adult Testing set's accuracy: %.2f" % accuracy_score(y_adult_test, y_adult_pred))
print("Adolescent Testing Set's accuracy: %.2f" % accuracy_score(y_adol_test, y_adol_pred))
print("Child Testing Set's accuracy: %.2f" % accuracy_score(y_child_test, y_child_pred))

