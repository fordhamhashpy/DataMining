# Data Mining Project (Naive Bayers Algo)

import numpy as np
import pandas as pd
from sklearn.naive_bayes import GaussianNB
from sklearn import metrics
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
  

                                # Dataset import
#data = pd.read_csv("Autism-Adult-Data.CSV", na_values = "?")
#data = pd.read_csv("Autism-Child-Data.csv", na_values = "?")
data = pd.read_csv("Autism-Adolescent-Data.csv", na_values = "?")

                                # Print dataset imported
print('Imported Training DataSet:\n', data.head())

                                # Data preprocessing
totalMissingData = data.isnull().sum().sort_values(ascending = False)
percentMissingData = (data.isnull().sum() / data.isnull().count() * 100).sort_values(ascending = False)
missingData = pd.concat([totalMissingData, percentMissingData], axis = 1, keys = ['Total', 'Percent'])

print('Total Missing Data:\n', missingData.head())
data = data.fillna(data.mean())
data.rename(columns = {'Class/ASD': 'decision_class'}, inplace = True)
data.jundice = data.jundice.apply(lambda x: 0 if x == 'no' else 1)
data.decision_class = data.decision_class.apply(lambda x: 0 if x == 'NO' else 1)
data.austim = data.austim.apply(lambda x: 0 if x == 'no' else 1)
lblEncode = LabelEncoder()
data.gender = lblEncode.fit_transform(data.gender) 

data.drop(['result'], axis = 1, inplace = True)
X=data[['A1_Score', 'A2_Score', 'A3_Score', 'A4_Score', 'A5_Score', 'A6_Score', 'A7_Score', 'A8_Score', 
       'A9_Score', 'A10_Score', 'age', 'austim', 'gender', 'jundice']]
Y=data[['decision_class']]


                                # Splitting data into training dataset and test dataset
X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size = 0.2)
feature_names = X.columns
print('\nFeature Names:\n', feature_names)

                                # Naive Bayers Algorithm
gnb = GaussianNB()
                                #Train the model using the training sets
gnb.fit(X_train, y_train.values.ravel())
y_pred = gnb.predict(X_test)

                                # Model Accuracy
print("\n Accuracy:",metrics.accuracy_score(y_test, y_pred))
print(" \n\n Confusion Matirx - \n")
print(metrics.confusion_matrix(y_test, y_pred))

